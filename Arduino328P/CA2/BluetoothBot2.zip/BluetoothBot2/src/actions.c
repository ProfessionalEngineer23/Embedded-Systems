#include "actions.h"
#include "usart.h"
#include "pwm.h"
#include <avr/io.h>
#define F_CPU 16000000UL  // 16 MHz CPU clock
#include <util/delay.h>

#define TIME0 100
#define TIME1 1600
#define TIME2 2000

/*****************************************************
 * This function checks if 'S' has been received to stop the robot
 ****************************************************/
uint8_t checkForStop() 
{
    if (usartCharReceived()) // Only check if character is available
    {
        char receivedChar = usartReadChar(); 
        if (receivedChar == 'S') 
        {
            stop();
            return 1;
        }
    }
    return 0;
}

/*****************************************************
 * Function to turn ON front lights (PD2 & PD3)
 ****************************************************/
void frontLightsON()
{
    PORTD |= (1 << PD2) | (1 << PD3);  // Turn ON both Front Left & Front Right lights
}

/*****************************************************
 * Function to turn OFF front lights (PD2 & PD3)
 ****************************************************/
void frontLightsOFF()
{
    PORTD &= ~((1 << PD2) | (1 << PD3));  // Turn OFF both Front Left & Front Right lights
}

/*****************************************************
 * Function to turn ON back lights (PD4 & PD7)
 ****************************************************/
void backLightsON()
{
    PORTD |= (1 << PD4) | (1 << PD7);  // Turn ON both Back Left & Back Right lights
}

/*****************************************************
 * Function to turn OFF back lights (PD4 & PD7)
 ****************************************************/
void backLightsOFF()
{
    PORTD &= ~((1 << PD4) | (1 << PD7));  // Turn OFF both Back Left & Back Right lights
}

/*****************************************************
 * Function to make robot go forward
 ****************************************************/
void forward(void)
{
	PORTC = 0x0A; // Make PC3 and PC1 high (0b0000 1010)
	setMotorSpeed(baseSpeed, baseSpeed - 5);  // -5 for right wheel drift correction
}

/*****************************************************
 * Function to make robot go backwards/ reverse
 ****************************************************/
void reverse(void) 
{
    PORTC = 0x05; // Make PC2 and PC0 high (0b0000 0101
	setMotorSpeed(baseSpeed, baseSpeed - 5);  // -5 for right wheel drift correction
	backLightsON();
	// For loop to Beep buzzer 4 times
    for (uint8_t i = 0; i < 4; i++) {
        PORTB |= (1 << PB0);  // Turn Buzzer ON
        _delay_ms(300);
        PORTB &= ~(1 << PB0); // Turn Buzzer OFF
        _delay_ms(200);
    }
}

/*****************************************************
 * Function to make robot turn right (Right Indicator blinks)
 ****************************************************/
void right(void) 
{
    PORTC = 0x06; // Set motor direction to turn right
	setMotorSpeed(baseSpeed, baseSpeed - 5);  // -5 for drift correction

    for (uint8_t i = 0; i < 5; i++)  // For loop to Blink 5 times while turning
    {
		checkForStop();
        PORTD |= (1 << PD2);  // Turn ON Right Front Light
        PORTD |= (1 << PD4);  // Turn ON Right Back Light
        _delay_ms(TIME0);       // Keep ON for 300ms

        PORTD &= ~(1 << PD2);  // Turn OFF Right Front Light
        PORTD &= ~(1 << PD4);  // Turn OFF Right Back Light
        _delay_ms(TIME0);        // Keep OFF for 300ms
    }
}

/*****************************************************
 * Function to make robot turn left (Left Indicator blinks)
 ****************************************************/
void left(void)
{
    PORTC = 0x09; // Set motor direction to turn left
	setMotorSpeed(baseSpeed, baseSpeed - 5);  // -5 for drift correction

    for (uint8_t i = 0; i < 5; i++)  // For loop to Blink 5 times
    {
		checkForStop();
        PORTD |= (1 << PD3);  // Turn ON Left Front Light
        PORTD |= (1 << PD7);  // Turn ON Left Back Light
        _delay_ms(TIME0);       // Keep ON for 300ms

        PORTD &= ~(1 << PD3);  // Turn OFF Left Front Light
        PORTD &= ~(1 << PD7);  // Turn OFF Left Back Light
        _delay_ms(TIME0);        // Keep OFF for 300ms
    }
}

/*****************************************************
 * Function to stop the robot. Turns off all lights
 ****************************************************/
void stop(void)
{
    PORTC &= ~(0x0F); // Stop all motors

    // Turn OFF all lights 
    PORTD &= ~(1 << PD2);  // Turn OFF Left Front Light
    PORTD &= ~(1 << PD3);  // Turn OFF Right Front Light
    PORTD &= ~(1 << PD4);  // Turn OFF Left Back Light
    PORTD &= ~(1 << PD7);  // Turn OFF Right Back Light
}

/*****************************************************
 * Function to stall robot motors/ essentially a stop
 ****************************************************/
void stall()
{
    PORTC = 0x0F; // 0b0000 1111
    _delay_ms(TIME1);
    PORTC = 0x00; // 0b0000 0000
    _delay_ms(TIME1);
}

/*****************************************************
 * Function to dance with immediate stop checks
 ****************************************************/
void dance()
{
    // Spin Right
    right();
    _delay_ms(TIME1);
    if (checkForStop()) return;

    stop();
    _delay_ms(TIME2);
    if (checkForStop()) return;

    // Move Forward
    forward();
    _delay_ms(TIME2);
    if (checkForStop()) return;

    stop();
    _delay_ms(TIME2);
    if (checkForStop()) return;

    // Spin Left
    left();
    _delay_ms(TIME1);
    if (checkForStop()) return;

    stop();
    _delay_ms(TIME2);
}

/*****************************************************
 * Function to execute actions based on received character
 ****************************************************/

void actionChoice(char ch)
{
    switch (ch)
    {
		// Duty Cycle = (Pulse Width * 100) / Period
        // Cases for setting speed values
        case '0': stop(); break; // 0 for stop
        case '1': baseSpeed = 100; break; // 1 for 100 out of 255
        case '2': baseSpeed = 120; break; // 2 for 120 out of 255
        case '3': baseSpeed = 140; break; // 3 for 140 out of 255
        case '4': baseSpeed = 160; break; // 4 for 160 out of 255
        case '5': baseSpeed = 180; break; // 5 for 180 out of 255
        case '6': baseSpeed = 200; break; // 6 for 200 out of 255
        case '7': baseSpeed = 220; break; // 7 for 220 out of 255
        case '8': baseSpeed = 240; break; // 8 for 240 out of 255
        case '9': baseSpeed = 255; break; // 9 for 255 out of 255
        case 'q': baseSpeed = 255; break; // q for 255 out of 255

        // Movement commands
        case 'F': forward(); break;
        case 'B': reverse(); break;
        case 'L': left(); break;
        case 'R': right(); break;
        case 'S': stop(); break;

        // Features
        case 'n': PORTB |= (1 << 5); break; // Turn on LED PB5 high
        case 'o': PORTB &= ~(1 << 5); break; // Turn off LED PB5 low
        case 'V': PORTB |= (1 << 0); break; // Turn on Buzzer PB0 high
        case 'v': PORTB &= ~(1 << 0); break; // Turn off Buzzer PB0 low
        case 'K': dance(); break; // Perform a dance move 
		case 'k': stop(); break; // Stop 
        case 'W': frontLightsON(); break; // Turn on PD2 AND PD3 Front Lights
        case 'w': frontLightsOFF(); break; // Turn off PD2 AND PD3 Front Lights
        case 'U': backLightsON(); break; // Turn on PD4 AND PD7 Back Lights
        case 'u': backLightsOFF(); break; // Turn off PD4 AND PD7 Back Lights
		
        default: stop(); break;
    }
}
