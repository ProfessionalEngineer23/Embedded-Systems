#include <avr/io.h>
#include "pwm.h"

uint8_t baseSpeed = 200;

/*****************************************************
 * This function is to initialize Timer0 for fast PWM mode
 ****************************************************/
void initPWM() 
{
    TCCR0A |= (1 << WGM00) | (1 << WGM01);
    TCCR0A |= (1 << COM0A1) | (1 << COM0B1);
    TCCR0B |= (1 << CS01) | (1 << CS00);
    DDRD |= (1 << PD5) | (1 << PD6);
    OCR0A = 200; //((200/255)*100) 78% Duty Cycle by default
    OCR0B = 200; //Speed number 6
}

/*****************************************************
 * This function is to set PWM duty cycle for each motor
 ****************************************************/
void setMotorSpeed(uint8_t leftSpeed, uint8_t rightSpeed) 
{
    OCR0A = leftSpeed;
    OCR0B = rightSpeed;
}
