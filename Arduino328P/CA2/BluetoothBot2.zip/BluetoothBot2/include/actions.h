/* 
	Library Prototype for Actions of Robot
	Created on: 5 Mar 2025
	Author: Niki Mardari
*/

#ifndef ACTIONS_H_
#define ACTIONS_H_

void forward(void);

void reverse(void);

void right(void);

void left(void);

void stop(void);

void stall(void);

void dance(void);

void frontLightsON(void);

void backLightsON(void);

void frontLightsOFF(void);

void backLightsOFF(void);

void actionChoice(char c);

#endif

