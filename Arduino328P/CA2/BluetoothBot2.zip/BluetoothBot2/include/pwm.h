/*
 * pwm.h
 *
 *  Created on: 23 Mar 2025
 *      Author: Niki Mardari
 */
 
 #ifndef PWM_H_
#define PWM_H_

#include <avr/io.h>
#include <stdint.h> 

/*****************************************************
 * This function is to initialize Timer0 for fast PWM mode
 ****************************************************/
void initPWM(void);

/*****************************************************
 * This function is to set PWM duty cycle for each motor
 ****************************************************/
void setMotorSpeed(uint8_t leftSpeed, uint8_t rightSpeed);

// External variable to store the base speed of the motor
extern uint8_t baseSpeed;

#endif 