#include <avr/io.h>
#include <stdio.h>
#include <util/delay.h>
#include "usart.h"
#include "temp.h"

static uint8_t tempEnabled = 0;

void setTempEnabled(uint8_t state) {
    tempEnabled = state;
}

uint8_t isTempEnabled(void) {
    return tempEnabled;
}

void tempInit(void) {
    // Set Vref to 1.1V
    ADMUX = (1 << REFS1) | (1 << REFS0);

    // Select ADC channel 5
    ADMUX |= (1 << MUX2) | (1 << MUX0);
    ADMUX &= ~(1 << MUX3 | 1 << MUX1);

    // ADC Prescaler = 128 for 125 kHz @16MHz
    ADCSRA |= (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);

    // Enable ADC
    ADCSRA |= (1 << ADEN);
}

void TempMeasure(void) {
    if (!tempEnabled) return;

    ADCSRA |= (1 << ADSC); // Start conversion
    while (ADCSRA & (1 << ADSC)); // Wait

    uint16_t adcCode = ADC;
    float voltage = adcCode / 1023.0 * 1.1;
    float temperature = voltage * 100.0;

    char str[64];
    sprintf(str, "Temp: %.2f C\r\n", temperature);
	usartSendString("TempMeasure() called\r\n"); // Debugging 
    usartSendString(str);
}
