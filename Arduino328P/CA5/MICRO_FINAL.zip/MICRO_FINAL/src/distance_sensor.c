#include "distance_sensor.h"
#include "ultrasonic.h"
#include "pwm.h"
#include "usart.h"
#include "millisMicrosDelay.h"
#include "actions.h" // for movement functions

#include <stdio.h>
#include <stdlib.h>

static uint8_t autonomousMode = 0;

void setAutonomousMode(uint8_t state) {
    autonomousMode = state;
}

uint8_t isAutonomousModeEnabled(void) {
    return autonomousMode;
}

void distanceSensorInit(void) {
    ultrasonicInit();  // You could keep this here or in harness.c
}

void distanceSensorRun(void) {
    if (!autonomousMode) return;

    char buffer[64];
    uint16_t dist = getDistance();

    if (dist < 400) {
        sprintf(buffer, "Distance: %u cm\r\n", dist);
        usartSendString(buffer);
    } else {
        usartSendString("No echo\r\n");
    }

    if (dist != 999 && dist < 50) {
        stop();
        delay(100);

        uint8_t direction = rand() % 2;
        uint16_t turnTime = 400 + rand() % 600;

        if (direction == 0) {
            left(200);
            usartSendString("Turning left\r\n");
        } else {
            right(200);
            usartSendString("Turning right\r\n");
        }

        delay(turnTime);
        stop();
        delay(100);
    } else if (dist != 999) {
        forward(200);
    }

    delay(50);
}
