#include "actions.h"
#include "usart.h"
#include "config.h"
#include "pwm.h"
#include "ultrasonic.h"
#include "millisMicrosDelay.h"
#define F_CPU 16000000UL
#include <util/delay.h>
#include <avr/io.h>

int main(void)
{
    initPWM();
    usartInit();
    setupPins();
    ultrasonicInit();
    millisMicrosDelayInit();
    tempInit();
    _delay_ms(500);

    char inputChar;

    while (1) {
        if (usartCharReceived()) {
            inputChar = usartReadChar();
            actionChoice(inputChar); // Process command
        }

        runTemperatureTask();     // Handle P/p temperature task
        runAutonomousTask();      // Handle C/c autonomous task
        handleBuzzerBeep();       // Blink buzzer if reversing
    }

    return 0;
}
