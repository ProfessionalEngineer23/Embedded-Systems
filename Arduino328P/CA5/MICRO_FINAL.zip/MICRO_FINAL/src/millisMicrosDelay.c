#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdint.h>
#include "millisMicrosDelay.h"

volatile uint32_t millis_counter = 0;
volatile uint32_t micros_counter = 0;

ISR(TIMER2_COMPA_vect)
{
    millis_counter++;
    micros_counter += 1000;
}

void millisMicrosDelayInit(void)
{
    TCCR2A = (1 << WGM21);             // CTC mode
    OCR2A = 249;                       // 1ms tick (16MHz/64/250)
    TCCR2B = (1 << CS22);              // Prescaler 64
    TIMSK2 = (1 << OCIE2A);            // Enable compare interrupt
    sei();                             // Global interrupt enable
}

uint32_t millis(void)
{
    return millis_counter;
}

uint32_t micros(void)
{
    return micros_counter;
}

void delay(uint32_t requestedDelay)
{
    uint32_t start = millis();
    while ((millis() - start) < requestedDelay);
}
