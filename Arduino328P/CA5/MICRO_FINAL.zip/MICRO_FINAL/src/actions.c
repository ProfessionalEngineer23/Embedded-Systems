// === actions.c ===
#include "actions.h"
#include "usart.h"
#include "pwm.h"
#include "ultrasonic.h"
#include "millisMicrosDelay.h"
#include <avr/io.h>
#include <stdlib.h>
#include <stdio.h>
#define F_CPU 16000000UL
#include <util/delay.h>

#define TIME1 1600
#define TIME2 500

static uint8_t tempEnabled = 0;
static uint8_t autonomousEnabled = 0;
static uint8_t isReversing = 0;
static uint8_t manualBuzzerOn = 0;

// === Lights ===
void frontLightsON()  { PORTB |= (1 << PB4) | (1 << PB3); }
void frontLightsOFF() { PORTB &= ~((1 << PB4) | (1 << PB3)); }
void backLightsON()   { PORTB |= (1 << PB2) | (1 << PB1); }
void backLightsOFF()  { PORTB &= ~((1 << PB2) | (1 << PB1)); }

// === Movement ===
void forward(uint8_t speed) { PORTC = 0x0A; setMotorSpeed(speed - 5, speed); isReversing = 0; }
void reverse(uint8_t speed) { PORTC = 0x05; setMotorSpeed(speed - 5, speed); backLightsON(); isReversing = 1; }
void right(uint8_t speed)   { PORTC = 0x06; setMotorSpeed(speed - 5, speed); PORTB |= (1 << PB3) | (1 << PB1); isReversing = 0; }
void left(uint8_t speed)    { PORTC = 0x09; setMotorSpeed(speed - 5, speed); PORTB |= (1 << PB4) | (1 << PB2); isReversing = 0; }

void stop(void) {
    PORTC &= ~(0x0F);
    PORTB &= ~((1 << PB1) | (1 << PB2) | (1 << PB3) | (1 << PB4));
    PORTB &= ~(1 << PB5);
    isReversing = 0;
}

void stall() {
    PORTC = 0x0F;
    _delay_ms(TIME1);
    PORTC = 0x00;
    _delay_ms(TIME1);
}

// === Dance Routine ===
uint8_t checkForStop() {
    if (usartCharReceived()) {
        char ch = usartReadChar();
        if (ch == 'S' || ch == 'k') {
            stop();
            return 1;
        }
    }
    return 0;
}

void dance() {
    uint8_t speed = 200;
    right(speed); _delay_ms(TIME1); if (checkForStop()) return;
    stop(); _delay_ms(TIME2); if (checkForStop()) return;
    forward(speed); _delay_ms(TIME2); if (checkForStop()) return;
    stop(); _delay_ms(TIME2); if (checkForStop()) return;
    left(speed); _delay_ms(TIME1); if (checkForStop()) return;
    stop(); _delay_ms(TIME2);
}

// === State Accessors ===
void setTempEnabled(uint8_t val) { tempEnabled = val; }
uint8_t isTempEnabled(void) { return tempEnabled; }

void setAutonomousEnabled(uint8_t val) { autonomousEnabled = val; }
uint8_t isAutonomousEnabled(void) { return autonomousEnabled; }

// === Temperature Monitoring ===
void tempInit(void) {
    ADMUX = (1 << REFS1) | (1 << REFS0);
    ADMUX &= ~(1 << MUX3);
    ADMUX |= (1 << MUX2);
    ADMUX &= ~(1 << MUX1);
    ADMUX |= (1 << MUX0);
    ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
    _delay_ms(10);
}

void runTemperatureTask(void) {
    static uint32_t lastTempTime = 0;
    if (!tempEnabled) return;

    uint32_t now = millis();
    if (now - lastTempTime >= 1000) {
        uint16_t adcCode;
        float voltage;
        char str[100];

        ADCSRA |= (1 << ADSC);
        while (ADCSRA & (1 << ADSC));

        adcCode = ADC;
        voltage = (adcCode * 1.1) / 1023.0;
        float temperature = voltage * 100.0;

        sprintf(str, "Temp: %.2f C\r\n", temperature);
        usartSendString(str);

        lastTempTime = now;
    }
}

// === Buzzer Beep While Reversing ===
void handleBuzzerBeep(void) {
    static uint32_t lastBeepTime = 0;
    static uint8_t buzzerState = 0;

    if (manualBuzzerOn) return;

    if (isReversing) {
        uint32_t now = millis();
        if (now - lastBeepTime >= 300) {
            buzzerState = !buzzerState;
            if (buzzerState)
                PORTB |= (1 << PB5);
            else
                PORTB &= ~(1 << PB5);
            lastBeepTime = now;
        }
    } else {
        PORTB &= ~(1 << PB5);
    }
}

// === Autonomous Navigation ===
void runAutonomousTask(void) {
    if (!autonomousEnabled) return;

    uint16_t dist = getDistance();
    char buffer[64];

    if (dist < 400) {
        sprintf(buffer, "Distance: %u cm\r\n", dist);
        usartSendString(buffer);
    } else {
        usartSendString("No echo\r\n");
    }

    if (dist != 999 && dist < 50) {
        stop();
        delay(100);
        uint8_t direction = rand() % 2;
        uint16_t turnTime = 400 + rand() % 600;

        if (direction == 0) {
            left(200);
            usartSendString("Turning left\r\n");
        } else {
            right(200);
            usartSendString("Turning right\r\n");
        }

        delay(turnTime);
        stop();
        delay(100);
    } else if (dist != 999) {
        forward(200);
    }

    delay(50);
}

// === Command Dispatcher ===
void actionChoice(char ch) {
    static uint8_t currentSpeed = 200;

    switch (ch) {
        case '0': stop(); break;
        case '1': currentSpeed = 100; break;
        case '2': currentSpeed = 120; break;
        case '3': currentSpeed = 140; break;
        case '4': currentSpeed = 160; break;
        case '5': currentSpeed = 180; break;
        case '6': currentSpeed = 200; break;
        case '7': currentSpeed = 220; break;
        case '8': currentSpeed = 240; break;
        case '9': currentSpeed = 255; break;
        case 'q': currentSpeed = 255; break;

        case 'F': forward(currentSpeed); break;
        case 'B': reverse(currentSpeed); break;
        case 'L': left(currentSpeed); break;
        case 'R': right(currentSpeed); break;
        case 'S': stop(); break;

        case 'K': dance(); break;
        case 'k': stop(); break;

        case 'n': PORTB |= (1 << PB5); break;
        case 'o': PORTB &= ~(1 << PB5); break;
        case 'V': manualBuzzerOn = 1; PORTB |= (1 << PB5); break;
        case 'v': manualBuzzerOn = 0; PORTB &= ~(1 << PB5); break;

        case 'W': frontLightsON(); break;
        case 'w': frontLightsOFF(); break;
        case 'U': backLightsON(); break;
        case 'u': backLightsOFF(); break;

        case 'P': tempEnabled = 1; usartSendString("Temperature Monitoring ON\r\n"); break;
        case 'p': tempEnabled = 0; usartSendString("Temperature Monitoring OFF\r\n"); break;

        case 'C': autonomousEnabled = 1; usartSendString("Autonomous Mode ENABLED\r\n"); break;
        case 'c': autonomousEnabled = 0; stop(); usartSendString("Autonomous Mode DISABLED\r\n"); break;
    }
}
