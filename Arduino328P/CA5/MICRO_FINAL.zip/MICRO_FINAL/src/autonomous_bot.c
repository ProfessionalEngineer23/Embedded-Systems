#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
#include <stdio.h>
#include <avr/interrupt.h>

// --- Variables ---
volatile uint8_t distanceFlag = 0;
volatile uint16_t startCount = 0, stopCount = 0;
volatile uint32_t millisCounter = 0;

// --- ISR for input capture ---
ISR(TIMER1_CAPT_vect)
{
    if (TCCR1B & (1 << ICES1)) {
        startCount = ICR1;
        TCCR1B &= ~(1 << ICES1); // Switch to falling edge
    } else {
        stopCount = ICR1;
        TCCR1B |= (1 << ICES1);  // Switch to rising edge
        distanceFlag = 1;
    }
}

// --- Timer2 Compare Match ISR for millis ---
ISR(TIMER2_COMPA_vect)
{
    millisCounter++;
}

// --- USART functions ---
void usartInit(void)
{
    UBRR0L = 103;  // 9600 baud @ 16MHz
    UCSR0B = (1 << TXEN0);
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

void usartSendChar(char data)
{
    while (!(UCSR0A & (1 << UDRE0)));
    UDR0 = data;
}

void usartSendString(const char *str)
{
    while (*str) {
        usartSendChar(*str++);
    }
}

// --- PWM motor setup ---
void initPWM(void)
{
    TCCR0A = (1 << WGM00) | (1 << WGM01) | (1 << COM0A1) | (1 << COM0B1);
    TCCR0B = (1 << CS01); // prescaler 8

    DDRD |= (1 << PD5) | (1 << PD6); // PWM outputs
}

void setMotorSpeed(uint8_t left, uint8_t right)
{
    OCR0A = left;
    OCR0B = right;
}

// --- Movement functions ---
void forward(void)
{
    PORTC = 0x0A;
    setMotorSpeed(255, 255); // Full speed
}

void left(void)
{
    PORTC = 0x09;
    setMotorSpeed(255, 255);
}

void right(void)
{
    PORTC = 0x06;
    setMotorSpeed(255, 255);
}

void stop(void)
{
    PORTC = 0x00;
    setMotorSpeed(0, 0);
}

// --- Ultrasonic functions ---
void ultrasonicInit(void)
{
    DDRD |= (1 << PD7);   // TRIG
    DDRB &= ~(1 << PB0);  // ECHO

    TCCR1A = 0;
    TCCR1B = (1 << ICES1) | (1 << CS11); // Rising edge, prescaler 8
    TIMSK1 = (1 << ICIE1);
    sei();
}

uint16_t getDistance(void)
{
    distanceFlag = 0;
    TCNT1 = 0;

    PORTD |= (1 << PD7);
    _delay_us(10);
    PORTD &= ~(1 << PD7);

    uint32_t timeout = 0;
    while (!distanceFlag && timeout++ < 60000) {
        _delay_us(1);
    }

    if (distanceFlag) {
        uint16_t pulse = stopCount - startCount;
        pulse /= 2;
        return pulse / 58; // Distance in cm
    }

    return 999; // No echo
}

// --- Setup pins ---
void setupPins(void)
{
    DDRC |= (1 << PC0) | (1 << PC1) | (1 << PC2) | (1 << PC3); // Motor directions
}

// --- millisMicrosDelay functions ---
void millisMicrosDelayInit(void)
{
    TCCR2A = (1 << WGM21); // CTC mode
    TCCR2B = (1 << CS22);  // Prescaler 64
    OCR2A = 249;           // 1ms tick
    TIMSK2 = (1 << OCIE2A);
    sei();
}

void delay(uint32_t ms)
{
    uint32_t start = millisCounter;
    while ((millisCounter - start) < ms);
}

// --- Main ---
int main(void)
{
    initPWM();
    setupPins();
    usartInit();
    ultrasonicInit();
    millisMicrosDelayInit();

    delay(500); // Sensor warmup

    char buffer[32];

    while (1)
    {
        uint16_t distance = getDistance();

        if (distance < 400) {
            sprintf(buffer, "Distance: %u cm\r\n", distance);
            usartSendString(buffer);
        } else {
            usartSendString("No echo\r\n");
        }

        if (distance < 50) // Obstacle detected
        {
            stop();
            delay(300);

            uint8_t direction = rand() % 2;
            uint16_t turnDuration = 900; // ~180 degrees

            if (direction == 0) {
                left();   // No parameter - just full speed
            } else {
                right();
            }

            delay(turnDuration);
            stop();
            delay(300);
        }
        else if (distance < 400)
        {
            forward();
        }
        else
        {
            stop();
        }

        delay(100);
    }
}
