#ifndef ULTRASONIC_H
#define ULTRASONIC_H

#include <stdint.h>

void ultrasonicInit(void);
uint16_t getDistance(void);

#endif
