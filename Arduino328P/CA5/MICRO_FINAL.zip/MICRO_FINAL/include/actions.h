#ifndef ACTIONS_H_
#define ACTIONS_H_

#include <stdint.h>

// === Movement ===
void forward(uint8_t speed);
void reverse(uint8_t speed);
void right(uint8_t speed);
void left(uint8_t speed);
void stop(void);
void stall(void);
void dance(void);

// === Lights ===
void frontLightsON(void);
void frontLightsOFF(void);
void backLightsON(void);
void backLightsOFF(void);

// === Command handler ===
void actionChoice(char ch);

// === Sensor state control ===
void tempInit(void);
void runTemperatureTask(void);
uint8_t isTempEnabled(void);
void setTempEnabled(uint8_t enabled);

void runAutonomousTask(void);
uint8_t isAutonomousEnabled(void);
void setAutonomousEnabled(uint8_t enabled);

// === Buzzer reverse indicator ===
void handleBuzzerBeep(void);

#endif /* ACTIONS_H_ */
