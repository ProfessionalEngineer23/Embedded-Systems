#ifndef DISTANCE_SENSOR_H
#define DISTANCE_SENSOR_H

#include <stdint.h>

void distanceSensorInit(void);
void distanceSensorRun(void);
void setAutonomousMode(uint8_t state);
uint8_t isAutonomousModeEnabled(void);

#endif
