#ifndef TEMP_H
#define TEMP_H

#include <stdint.h>

void tempInit(void);
void TempMeasure(void);
void setTempEnabled(uint8_t state);
uint8_t isTempEnabled(void);

#endif
