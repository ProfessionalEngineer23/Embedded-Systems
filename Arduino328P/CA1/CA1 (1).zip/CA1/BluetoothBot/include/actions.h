/* 
	Library Prototype for Actions of Robot
	Created on: 5 Mar 2025
	Author: Niki Mardari
*/

#ifndef ACTIONS_H_
#define ACTIONS_H_

/*****************************************************
 * This function should make the bot go forward
 ****************************************************/
void forward(void);

/*****************************************************
 * This function should make the bot go backwards/ reverse
 ****************************************************/
void reverse(void);

/*****************************************************
 * This function should make the bot turn right 
 ****************************************************/
void right(void);

/*****************************************************
 * This function should make the bot turn left 
 ****************************************************/
void left(void);

/*****************************************************
 * This function should make the bot stop
 ****************************************************/
void stop(void);

/*****************************************************
 * This function should set up the USART for 9600 8N1
 ****************************************************/
void stall(void);

/*****************************************************
 * This function should set up the USART for 9600 8N1
 ****************************************************/
void dance(void);

/*****************************************************
 * This function should turn on the front two LEDS
 ****************************************************/
void frontLightsON(void);

/*****************************************************
 * This function should turn on the back two LEDS
 ****************************************************/
void backLightsON(void);

/*****************************************************
 * This function should turn off the front two LEDS
 ****************************************************/
void frontLightsOFF(void);

/*****************************************************
 * This function should turn off the back two LEDS
 ****************************************************/
void backLightsOFF(void);

/*****************************************************
 * This function should set up the USART for 9600 8N1
 ****************************************************/
void actionChoice(char c);

#endif

