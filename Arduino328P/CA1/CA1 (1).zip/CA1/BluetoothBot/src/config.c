#define F_CPU 16000000UL  // 16 MHz CPU clock
#include <util/delay.h>
#include "config.h"

/*****************************************************
 * Function to initialize pin configurations
 ****************************************************/
void setupPins(void)
{
    // Set PB5 as output for Onboard LED control
    DDRB |= (1 << PB5);  

    // Set PB0 as output for Buzzer control
    DDRB |= (1 << PB0);         
    
	//Front lights pins PD2, PD3 set as output 
	DDRD |= (1 << PD2); //Right
	DDRD |= (1 << PD3); //Left
	
	//Set Back lights pins PD4, PD5 set as output
	DDRD |= (1 << PD4); //Right 
	DDRD |= (1 << PD5); //Left
	
    _delay_ms(50);  // Small delay for pin reading stabilization
}
