#define F_CPU 16000000UL
#include <stdint.h>
#include <util/delay.h>
#include <avr/io.h>
#include "usart.h" 
#include "actions.h"
#include "config.h"

int main(void)
{
    usartInit();   // Initialize USART for serial communication
    setupPins();   // Configure LED, Buzzer, and other necessary pins

    char ch; // Variable to store received character

    while (1) {
        // Check if a character has been received via USART
        if (usartCharReceived()) {  
            ch = usartReadChar();  // Read the received character
            actionChoice(ch);      // Execute corresponding action based on input
        }

    }

    return 0; // This will never be reached in my embedded system! Unless required.
}
