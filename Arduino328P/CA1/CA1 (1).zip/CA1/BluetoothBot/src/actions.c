#include "actions.h"
#include "usart.h"
#include <avr/io.h>
#define F_CPU 16000000UL  // 16 MHz CPU clock
#include <util/delay.h>

#define TIME0 300
#define TIME1 1600
#define TIME2 2000

/*****************************************************
 * This safety function checks if Stop was pressed to stop the robot even during a function
 ****************************************************/
uint8_t checkForStop() 
{
    if (usartCharReceived()) // Only execute if a new character is received
    {
        char receivedChar = usartReadChar(); 
        if (receivedChar == 'S') 
        {
            stop();
            return 1;
        }
    }
    return 0;
}

/*****************************************************
 * Function to turn ON front lights (PD2 & PD3)
 ****************************************************/
void frontLightsON()
{
    PORTD |= (1 << PD2) | (1 << PD3);  // Turn ON both Front Left & Front Right lights
}

/*****************************************************
 * Function to turn OFF front lights (PD2 & PD3)
 ****************************************************/
void frontLightsOFF()
{
    PORTD &= ~((1 << PD2) | (1 << PD3));  // Turn OFF both Front Left & Front Right lights
}

/*****************************************************
 * Function to turn ON back lights (PD4 & PD5)
 ****************************************************/
void backLightsON()
{
    PORTD |= (1 << PD4) | (1 << PD5);  // Turn ON both Back Left & Back Right lights
}

/*****************************************************
 * Function to turn OFF back lights (PD4 & PD5)
 ****************************************************/
void backLightsOFF()
{
    PORTD &= ~((1 << PD4) | (1 << PD5));  // Turn OFF both Back Left & Back Right lights
}

/*****************************************************
 * Function to make robot go forward
 ****************************************************/
void forward(void)
{
    PORTC = 0x0A; // Make PC3 and PC1 high (0b0000 1010)
}

/*****************************************************
 * Function to make robot go backwards/ reverse
 ****************************************************/
void reverse(void) 
{
    PORTC = 0x05; // Make PC2 and PC0 high (0b0000 0101)
	backLightsON();
}

/*****************************************************
 * Function to make robot turn right (Right Indicator blinks)
 ****************************************************/
void right(void) 
{
    PORTC = 0x06; // Set motor direction to turn right

    for (uint8_t i = 0; i < 5; i++)  // For loop to Blink 5 times while turning
    {
        PORTD |= (1 << PD2);  // Turn ON Right Front Light
        PORTD |= (1 << PD4);  // Turn ON Right Back Light
        _delay_ms(TIME0);

        PORTD &= ~(1 << PD2);  // Turn OFF Right Front Light
        PORTD &= ~(1 << PD4);  // Turn OFF Right Back Light
        _delay_ms(TIME0);        // Keep OFF for 300ms
    }
}

/*****************************************************
 * Function to make robot turn left (Left Indicator blinks)
 ****************************************************/
void left(void)
{
    PORTC = 0x09; // Set motor direction to turn left

    for (uint8_t i = 0; i < 5; i++)  // For loop to Blink 5 times
    {
        PORTD |= (1 << PD3);  // Turn ON Left Front Light
        PORTD |= (1 << PD5);  // Turn ON Left Back Light
        _delay_ms(TIME0);       // Keep ON for 300ms

        PORTD &= ~(1 << PD3);  // Turn OFF Left Front Light
        PORTD &= ~(1 << PD5);  // Turn OFF Left Back Light
        _delay_ms(TIME0);        // Keep OFF for 300ms
    }
}

/*****************************************************
 * Function to stop the robot. Turns off all lights
 ****************************************************/
void stop(void)
{
    PORTC &= ~(0x0F); // Stop all motors

    // Turn OFF all lights 
    PORTD &= ~(1 << PD2);  // Turn OFF Left Front Light
    PORTD &= ~(1 << PD3);  // Turn OFF Right Front Light
    PORTD &= ~(1 << PD4);  // Turn OFF Left Back Light
    PORTD &= ~(1 << PD5);  // Turn OFF Right Back Light
}

/*****************************************************
 * Function to stall robot motors/ essentially a stop
 ****************************************************/
void stall()
{
    PORTC = 0x0F; // 0b0000 1111
    _delay_ms(TIME1);
    PORTC = 0x00; // 0b0000 0000
    _delay_ms(TIME1);
}

/*****************************************************
 * Function to dance with immediate stop checks
 ****************************************************/
void dance()
{
    // Spin Right
    right();
    _delay_ms(TIME1);
    if (checkForStop()) return;

    stop();
    _delay_ms(TIME2);
    if (checkForStop()) return;

    // Move Forward
    forward();
    _delay_ms(TIME2);
    if (checkForStop()) return;

    stop();
    _delay_ms(TIME2);
    if (checkForStop()) return;

    // Spin Left
    left();
    _delay_ms(TIME1);
    if (checkForStop()) return;

    stop();
    _delay_ms(TIME2);
}

/*****************************************************
 * Function to execute actions based on received character
 ****************************************************/
void actionChoice(char ch)
{
    switch (ch) 
	{
        case 'F': forward(); break;
        case 'B': reverse(); break;
        case 'S': stop(); break;
        case 'L': left(); break;
        case 'R': right(); break;
        case 'n': PORTB |= (1 << 5); break;  // Turn on LED PB5 high
        case 'o': PORTB &= ~(1 << 5); break; // Turn off LED PB5 low
        case 'V': PORTB |= (1 << 0); break;  // Turn on Buzzer PB0 high
        case 'v': PORTB &= ~(1 << 0); break; // Turn off Buzzer PB0 low
        case 'D': dance(); break;
		case 'W': frontLightsON(); break;
		case 'w': frontLightsOFF(); break;
		case 'U': backLightsON(); break;
		case 'u': backLightsOFF(); break;
        default: stop(); break;
    }
}
